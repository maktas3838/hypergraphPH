Primary school: this dataset is made from a network of primary school students and teachers. A vertex is a student or a teacher, and a hyperedge is a set of students and/or teachers in close contact with each other.

Number of hyperedges:  242
Number of labels: 11
Maximum hyperedge size: 5 
Total number of hyperedges: 12704

Files:

1. nverts_primary_school.txt: This file lists the number of vertices in each hyperedge.
2. simplices_primary_school.txt: This file lists the vertices in each hyperedge.
3. nlabels_primary_school.txt: This file has the vertex labels for each hypergraph.
4. gindicator_primary_school.txt: This file shows which hyperedge in nverts_primary_school.txt belongs to which hypergraph.
5. gverts_primary_school.txt: This file lists the number of vertices in each hypergraph.
6. glabels_high_school.txt: This file lists the hypergraph labels.