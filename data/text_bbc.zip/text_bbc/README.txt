This dataset is constructed from the text dataset from the following paper: 
- D. Greene and P. Cunningham. "Practical Solutions to the Problem of Diagonal Dominance in Kernel Document Clustering", Proc. ICML 2006. 

It consists of 2225 documents from the BBC news website corresponding to stories in five topical areas from 2004-2005.
There are five different text classes: business, entertainment, politics, sport, tech

Each hypergraph is a document where its notes are words and a sentence forms hyperedges.

Number of songs: 2225
Number of labels: 5
Maximum hyperedge size: 159
Total number of hyperedges: 41,403

Files:

1. text_bbc_nverts.txt: This file lists the number of vertices in each hyperedge.
2. text_bbc_simplices.txt: This file lists the vertices in each hyperedge.
3. text_bbc_gindicator.txt: This file shows which hyperedge in text_bbc_nverts.txt belongs to which hypergraph.
4. text_bbc_gverts.txt: This file lists the number of vertices in each hypergraph.
5. text_bbc_glabels.txt: This file lists the hypergraph labels.

If you make use of the dataset, please consider citing the publication: 
