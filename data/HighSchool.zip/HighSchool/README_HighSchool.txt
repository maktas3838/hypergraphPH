High school: this dataset is made from a network of high school students in Marseilles, France. A vertex is a student, and a hyperedge is a set of students in close contact with each other.

Number of hyperedges:  327 
Number of labels: 9 
Maximum hyperedge size: 5 
Total number of hyperedges: 7818 

Files:

1. nverts_high_school.txt: This file lists the number of vertices in each hyperedge.
2. simplices_high_school.txt: This file lists the vertices in each hyperedge.
3. nlabels_high_school.txt: This file has the vertex labels for each hypergraph.
4. gindicator_high_school.txt: This file shows which hyperedge in nverts_high_school.txt belongs to which hypergraph.
5. gverts_high_school.txt: This file lists the number of vertices in each hypergraph.
6. glabels_high_school.txt: This file lists the hypergraph labels.