This dataset is constructed from the makam music dataset at "https://github.com/MTG/SymbTr-pdf". Each hypergraph is a song where its notes are vertices and a set of notes corresponds to each syllable forms hyperedges. The hypergraph labels are makam music type of each song. 

// Check nature paper for description
// nlabels and glables to be interchanged

Number of songs: 832 // 327 
Number of labels: 15 // 9 for high school
Maximum hyperedge size: 87 / 5 for high school
Total number of hyperedges: 245,534 /7818 for high school

Files:

1. music_makam_nverts.txt: This file lists the number of vertices in each hyperedge.
2. music_makam_simplices.txt: This file lists the vertices in each hyperedge.
3. music_makam_nlabels.txt: This file has the vertex labels (i.e. musical note) for each hypergraph.
4. music_makam_gindicator.txt: This file shows which hyperedge in music_makam_nverts.txt belongs to which hypergraph.
5. music_makam_gverts.txt: This file lists the number of vertices in each hypergraph.
6. music_makam_glabels.txt: This file lists the hypergraph labels.